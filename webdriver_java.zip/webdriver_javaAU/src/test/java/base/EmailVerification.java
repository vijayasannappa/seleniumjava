package base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class EmailVerification{

    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:/Users/d820244/workspace/study/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.get("https://www.guerrillamail.com/inbox");
    }

    @Test
    public void GoHome(){
        driver.findElement(By.xpath("//*[@id=\"inbox-id\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"inbox-id\"]/input")).sendKeys("vvvv");
        driver.findElement(By.xpath("//*[@id=\"inbox-id\"]/button[1]")).click();
        Boolean value = driver.findElement(By.xpath("//tr/td[contains(text(), 'XXXX')]")).isDisplayed();
       Assert.assertTrue(value);

    }

    @AfterClass
    public void TearDown(){
        driver.quit();
    }
}
