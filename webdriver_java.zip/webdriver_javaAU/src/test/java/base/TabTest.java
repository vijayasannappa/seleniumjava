package base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;

import java.util.concurrent.TimeUnit;

public class TabTest extends BaseTests{

    @Test(priority = 1)
    public void selectTab(){
        homepage.selectTab();
        Assert.assertEquals(homepage.clickEnglishText(), "English");
        Assert.assertEquals(homepage.clickDutchText(), "Dutch");
    }

    @Test(priority = 2)
    public void Register(){
        homepage.SignUp("XXXX","sss@yy.com","vvvv@sharklasers.com");
        System.out.println("Registrerd Successsfully");
    }
}
