package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;

import java.util.concurrent.TimeUnit;

public class BaseTests {

    private WebDriver driver;
    protected HomePage homepage;

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:/Users/d820244/workspace/study/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }

    @BeforeMethod
    public void GoHome(){
        driver.get("http://jt-dev.azurewebsites.net/#/SignUp");
        homepage = new HomePage(driver);
    }

    @AfterClass
    public void TearDown(){
        driver.quit();
    }




     /*  *//* driver.findElement(By.linkText("Inputs")).click();
        driver.navigate().back();
        List<WebElement> elements = driver.findElements(By.tagName("a"));
        System.out.println("List of elemnets with a are " + elements.size());*//*
       //Exercise
    *//*    driver.findElement(By.linkText("Shifting Content")).click();
        driver.findElements(By.linkText("Example 1: Menu Element"));
        List<WebElement> elements = driver.findElements(By.tagName("a"));
        System.out.println("List of elemnets with a are " + elements.size());*//*

        driver.findElement(By.linkText("Horizontal Slider")).click();
        driver.findElement(By.cssSelector("input[type=\"range\"]")).sendKeys(Keys.ARROW_RIGHT);
        driver.switchTo().alert()*/


}
