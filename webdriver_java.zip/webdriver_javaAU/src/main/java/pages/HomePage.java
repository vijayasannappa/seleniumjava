package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

    private WebDriver driver;
    private By Tab = By.id("language");
    private By en = By.linkText("English");
    private By du = By.linkText("Dutch");
    private By name = By.xpath("//*[@id=\"name\"]");
    private By orgName = By.xpath("//*[@id=\"orgName\"]");
    private By email = By.xpath("//*[@id=\"singUpEmail\"]");
    private By terms = By.xpath("//*[@id=\"content\"]/div/div[3]/div/section/div[1]/form/fieldset/div[4]/label/span");
    private  By submit = By.xpath("//*[@id=\"content\"]/div/div[3]/div/section/div[1]/form/fieldset/div[5]/button");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectTab() {
        driver.findElement(Tab).click();
    }

    public String clickEnglishText() {
        return driver.findElement(en).getText();
    }

    public String clickDutchText() {
        return driver.findElement(du).getText();
    }
    public void SignUp(String Name,String organizationName, String mailid) {
        driver.findElement(name).sendKeys(Name);
        driver.findElement(orgName).sendKeys(organizationName);
        driver.findElement(email).sendKeys(mailid);
        driver.findElement(terms).click();
        driver.findElement(submit).click();
    }



}
